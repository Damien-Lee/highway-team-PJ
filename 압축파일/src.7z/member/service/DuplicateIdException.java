package member.service;

public class DuplicateIdException extends RuntimeException {

}
