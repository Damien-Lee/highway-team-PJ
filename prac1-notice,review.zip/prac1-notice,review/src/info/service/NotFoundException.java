package info.service;

public class NotFoundException extends RuntimeException {

}
