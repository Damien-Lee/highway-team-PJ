package notice.service;

import java.sql.Connection;
import java.sql.SQLException;

import jdbc.JdbcUtil;
import jdbc.connection.ConnectionProvider;
import notice.DAO.NoticeContentDAO;
import notice.DAO.NoticeDAO;
import notice.model.Notice;

//p667
//수정처리요청 컨트롤러에서 호출하는 서비스클래스
public class DeleteArticleService {

	private NoticeDAO articleDao = new NoticeDAO();
	private NoticeContentDAO contentDao = new NoticeContentDAO();
	
	//p667 17
	public void delete(DeleteRequest delReq) {
		Connection conn = null;
		try {
			conn = ConnectionProvider.getConnection();
			conn.setAutoCommit(false);
			
			//p667 23
			//articleDao.selectByID()는 p655 1
			Notice article = articleDao.selectByID(conn, 
					delReq.getArticleNumber());
			if(article==null) { //게실글이 없으면
				throw new ArticleNotFoundException();
			}
			if( !canDelete(delReq.getUserId(),article) ) {
				throw new PermissionDeniedException();
			}
			conn.commit();
		}catch(SQLException e) {
			JdbcUtil.rollback(conn);
			throw new RuntimeException();
		}catch(PermissionDeniedException e) {
			JdbcUtil.rollback(conn);
			throw e;
		}finally {
			JdbcUtil.close(conn);
		}
		
	}

	//p668 47
	//게시글을 수정할 수 있는 권한이 있는 검사
	//=>글작성자id와   로그인유저id 일치여부
	//  일치하면 true리턴, 불일치하면 false
	private boolean canDelete(String userId, Notice article) {
		//글작성자id
		String id = article.getWriter().getId();
		
		//글작성자id.equals(로그인유저id )
		return id.equals(userId);
	}
	
}






