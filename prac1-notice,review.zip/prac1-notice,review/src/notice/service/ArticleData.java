package notice.service;

import notice.model.Notice;
import notice.model.NoticeContent;

//p657
//article테이블과 article_content테이블의 결과를 
//하나의 객체로 묶어주는 클래스
public class ArticleData {

	private Notice article;
	private NoticeContent content;
	
	public ArticleData(Notice article,
			NoticeContent content) {
		this.article = article;
		this.content = content;
	}

	public Notice getArticle() {
		return article;
	}

	public void setArticle(Notice article) {
		this.article = article;
	}

	public NoticeContent getContent() {
		return content;
	}

	public void setContent(NoticeContent content) {
		this.content = content;
	}

	@Override
	public String toString() {
		return "ArticleData [article=" + article + ", content=" + content + "]";
	}
	
	
}









