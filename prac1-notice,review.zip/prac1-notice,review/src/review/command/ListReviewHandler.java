package review.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.command.CommandHandler;
import review.service.MessageListView;
import review.service.GetMessageListService;

//전체목록보기 요청 담당 컨트롤러
//P652
public class ListReviewHandler implements CommandHandler {

	//Service
	private GetMessageListService listService =
			GetMessageListService.getInstance();
	
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		//할일
		//1.파라미터 받기
		int pageNumber = Integer.parseInt(request.getParameter("PageNo"));//보고싶은페이지
		int pageNo = 1;
		if( pageNumber!=0 ) { //보고싶은페이지가 넘어오면
			pageNo = pageNumber;
		}
				
		//2.비즈니스로직(<->Service<->DAO<->DB) p652 22
		MessageListView reviewPage = 
				listService.getMessageList(pageNumber);
		
		//3.Model
		request.setAttribute("reviewPage", reviewPage);
				
		//4.View
		return "/view/review/review_list.jsp";
	}

}








