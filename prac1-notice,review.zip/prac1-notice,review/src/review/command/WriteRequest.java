package review.command;

import java.util.Map;

import review.model.Writer;

//p637
//글입력에 필요한 데이터를 제공
/*
insert into article(writer_id,writer_name,title,regdate,moddate,read_cnt)
values(writer_id?,writer_name?,title?,regdate?,moddate?,0);

insert into article_content(article_no,content)
values(article_no?,content?);
 */
public class WriteRequest {
	
	private Writer writer;		//writer_id 컬럼용,writer_name 컬럼용
	private int resatis;		//title컬럼용	 
	private String recontent;		//content컬럼용 
	
	//WriteRequest(String writer_id,String writer_name,String title,String content) {
	WriteRequest(Writer writer,int resatis,String content) {
		//this.writer_id	=writer_id;
		//this.writer_name=writer_name;
		this.writer		=writer;
		this.resatis		=resatis;
		this.recontent	=recontent;
	}
	
	
	public Writer getWriter() {
		return writer;
	}

	public void setWriter(Writer writer) {
		this.writer = writer;
	}

	public int getResatis() {
		return resatis;
	}

	public void setResatis(int resatis) {
		this.resatis = resatis;
	}

	public String getRecontent() {
		return recontent;
	}

	public void setRecontent(String recontent) {
		this.recontent = recontent;
	}


	//p638 31
	//title이 null인지에대한 체크=>유효성검사
	public void validate(Map<String, Boolean> errors) {
		if( recontent==null || recontent.trim().isEmpty() ) {
			errors.put("recontent",Boolean.TRUE);
		}
	}
}







