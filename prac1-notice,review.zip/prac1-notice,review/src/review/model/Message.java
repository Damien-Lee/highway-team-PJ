package review.model;

import java.sql.Timestamp;

//import member.MODEL.Member;

public class Message {
	private String restno;
	private String restname;
	private int reno;
	private String name;
	private String repw;
	private Timestamp redate;
	private String recontent;
	private int resatis;

	
	/* Member member = new Member(); */
	
	
	public int getReno() {
		return reno;
	}

	public String getRestno() {
		return restno;
	}

	public void setRestno(String restno) {
		this.restno = restno;
	}

	public String getRestname() {
		return restname;
	}

	public void setRestname(String restname) {
		this.restname = restname;
	}

	public void setReno(int reno) {
		this.reno = reno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRepw() {
		return repw;
	}

	public void setRepw(String repw) {
		this.repw = repw;
	}

	public String getRecontent() {
		return recontent;
	}

	public void setRecontent(String recontent) {
		this.recontent = recontent;
	}

	public int getResatis() {
		return resatis;
	}

	public void setResatis(int resatis) {
		this.resatis = resatis;
	}

	
	public Timestamp getRedate() {
		return redate;
	}

	public void setRedate(Timestamp redate) {
		this.redate = redate;
	}

	public boolean hasPassword() {
		return repw != null && !repw.isEmpty();
	}

	public boolean matchPassword(String password) {
		return repw != null && repw.equals(password);
	}

	@Override
	public String toString() {
		return "Message [restno=" + restno + ", restname=" + restname + ", reno=" + reno + ", name=" + name + ", repw="
				+ repw + ", redate=" + redate + ", recontent=" + recontent + ", resatis=" + resatis + "]";
	}
	
	/*
	 * public boolean hasName() { return name != null && !name.isEmpty(); }
	 * 
	 * public boolean matchName(String name) { return name != null &&
	 * name.equals(member.getName()); }
	 */

	
	
	
}