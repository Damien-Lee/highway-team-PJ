package review.model;

public class Message {

	private int reno;
	private String name;
	private String repw;
	private String recontent;
	private int resatis;

	
	public int getReno() {
		return reno;
	}

	public void setReno(int reno) {
		this.reno = reno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRepw() {
		return repw;
	}

	public void setRepw(String repw) {
		this.repw = repw;
	}


	public String getRecontent() {
		return recontent;
	}

	public void setRecontent(String recontent) {
		this.recontent = recontent;
	}

	public int getResatis() {
		return resatis;
	}

	public void setResatis(int resatis) {
		this.resatis = resatis;
	}

	public boolean hasPassword() {
		return repw != null && !repw.isEmpty();
	}

	public boolean matchPassword(String repw) {
		return repw != null && repw.equals(repw);
	}
	
	public boolean hasName() {
		return name != null && !name.isEmpty();
	}

	public boolean matchName(String name) {
		return name != null && name.equals(name);
	}

	@Override
	public String toString() {
		return "Message [reno=" + reno + ", name=" + name + ", repw=" + repw + ", recontent="
				+ recontent + ", resatis=" + resatis + "]";
	}
	
	
}