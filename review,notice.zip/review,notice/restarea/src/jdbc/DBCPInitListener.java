package jdbc;

import java.io.IOException;
import java.io.StringReader;
import java.sql.DriverManager;
import java.util.Properties;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.commons.dbcp2.ConnectionFactory;
import org.apache.commons.dbcp2.DriverManagerConnectionFactory;
import org.apache.commons.dbcp2.PoolableConnection;
import org.apache.commons.dbcp2.PoolableConnectionFactory;
import org.apache.commons.dbcp2.PoolingDriver;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

//P583
public class DBCPInitListener implements ServletContextListener {

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		String poolConfig = 
				sce.getServletContext().getInitParameter("poolConfig");
		Properties prop = new Properties();
		try {
			prop.load(new StringReader(poolConfig));
		} catch (IOException e) {
			throw new RuntimeException("config load fail", e);
		}
		loadJDBCDriver(prop);
		initConnectionPool(prop);
	}

	private void loadJDBCDriver(Properties prop) {
		//driverClass媛��졇�삤湲� <-Properties prop瑜� �넻�빐�꽌 jdbcdriver�씪�뒗 �씠由꾩쓽 Property遺덈윭�삤湲�
		String driverClass = prop.getProperty("jdbcdriver");
		try {
			Class.forName(driverClass);
		} catch (ClassNotFoundException ex) {
			throw new RuntimeException("fail to load JDBC Driver", ex);
		}
	}

	private void initConnectionPool(Properties prop) {
		try {
			String jdbcUrl = prop.getProperty("jdbcUrl");
			String username = prop.getProperty("dbUser");
			String pw = prop.getProperty("dbPass");

			////而ㅻ꽖�뀡���씠 	�깉濡쒖슫 而ㅻ꽖�뀡�쓣 �깮�꽦�븷 �븣 �궗�슜�븷	 ConnectionFactory瑜� �깮�꽦
			ConnectionFactory connFactory = 
					new DriverManagerConnectionFactory(jdbcUrl, username, pw);

			/* PoolableConnection�쓣 �깮�꽦�븯�뒗 �뙥�넗由� �깮�꽦.
			 * 	DBCP�뒗 而ㅻ꽖�뀡�쓣 蹂닿��븷 �븣 PoolableConnection �쓣 �궗�슜
             * 	�떎�젣 而ㅻ꽖�뀡�쓣 �떞怨� �엳�엳�쑝硫�, 而ㅻ꽖�뀡 ���쓣 愿�由ы븯�뒗�뜲 �븘�슂�븳 湲곕뒫�쓣 �젣怨듯븳�떎.
             * 	而ㅻ꽖�뀡�쓣 close�븯硫� 醫낅즺�븯吏� �븡怨� 而ㅻ꽖�뀡 ���뿉 諛섑솚*/
			PoolableConnectionFactory poolableConnFactory = 
					new PoolableConnectionFactory(connFactory, null);
			String validationQuery = prop.getProperty("validationQuery");
			if (validationQuery != null && !validationQuery.isEmpty()) {
				poolableConnFactory.setValidationQuery(validationQuery);
			}

			/*而ㅻ꽖�뀡 ���뿉 �엳�뒗 而ㅻ꽖�뀡 以� �삤�옖 �떆媛� �룞�븞 �궗�슜�릺吏� �븡�뒗 而ㅻ꽖�뀡�� 
			 * DBMS�� �뿰寃곗씠 �걡湲� 媛��뒫�꽦�씠 �넂怨�, 
			 * �뿰寃곗씠   �걡湲곕㈃ �봽濡쒓렇�옩 �떎�뻾 �룄以� �삤瑜섍� 諛쒖깮�븯誘�濡�
			 * ->二쇨린�쟻�쑝濡� 而ㅻ꽖�뀡 ���뿉 �엳�뒗 而ㅻ꽖�뀡�쓣 寃��궗�빐�꽌 
			 * 	  �궗�쟾�뿉 �젣嫄고븯�뒗 寃껋씠 �븘�슂
			 */
			GenericObjectPoolConfig poolConfig = new GenericObjectPoolConfig();
			poolConfig.setTimeBetweenEvictionRunsMillis(1000L * 60L * 5L);
			poolConfig.setTestWhileIdle(true);  //true�씠硫� �쑀�쑕而ㅻ꽖�뀡�씠 �쑀�슚�븳吏� 寃��궗.湲곕낯false
			int minIdle = getIntProperty(prop, "minIdle", 5);
			poolConfig.setMinIdle(minIdle);//���씠 �쑀吏��븷 而ㅻ꽖�뀡�쓽 理쒖냼�쑀�쑕媛쒖닔.湲곕낯媛�0
			int maxTotal = getIntProperty(prop, "maxTotal", 50);
			poolConfig.setMaxTotal(maxTotal);//���씠 愿�由ы븯�뒗 而ㅻ꽖�뀡�쓽 理쒕�媛쒖닔.湲곕낯媛�8.�쓬�닔�씠硫� 臾댄븳

			
			//而ㅻ꽖�뀡 ���쓣 �깮�꽦. 
			GenericObjectPool<PoolableConnection> connectionPool = 
					new GenericObjectPool<>(poolableConnFactory, poolConfig);
			poolableConnFactory.setPool(connectionPool);
			
			Class.forName("org.apache.commons.dbcp2.PoolingDriver");
			PoolingDriver driver = (PoolingDriver)
				DriverManager.getDriver("jdbc:apache:commons:dbcp:");
			
			System.out.println("prop.getProperty(poolName)="+prop.getProperty("poolName"));
			String poolName = prop.getProperty("poolName");
			driver.registerPool(poolName, connectionPool);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private int getIntProperty(Properties prop, String propName, int defaultValue) {
		String value = prop.getProperty(propName);
		if (value == null) return defaultValue;
		return Integer.parseInt(value);
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
	}

}
