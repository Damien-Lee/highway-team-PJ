package notice.service;

//666
public class PermissionDeniedException extends RuntimeException {
	
}
