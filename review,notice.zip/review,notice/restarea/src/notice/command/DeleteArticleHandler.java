package notice.command;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import auth.service.User;
import mvc.command.CommandHandler;
import notice.service.ArticleData;
import notice.service.ArticleNotFoundException;
import notice.service.DeleteRequest;
import notice.service.PermissionDeniedException;
import notice.service.ReadArticleService;
import notice.service.DeleteArticleService;

public class DeleteArticleHandler implements CommandHandler {

	//View
	private static final String FORM_VIEW
		="/view/admin/notice/notice_deleMessage.jsp";
	
	//Service
	//수정처리용 서비스
	private DeleteArticleService deleteService =
			new DeleteArticleService();
	
	//상세내용조회 서비스
	private ReadArticleService readService =
			new ReadArticleService();
	
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
		if(request.getMethod().equalsIgnoreCase("GET")) {
			return processForm(request,response);
		}else if(request.getMethod().equalsIgnoreCase("POST")) { //POST방식으로 요청이 들어오면
			return processSubmit(request,response);
		}else {
			//405에러
			response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED); 
			return   null;
		}
	}

	private String processSubmit(HttpServletRequest request, 
			HttpServletResponse response) throws Exception{
		//1.파라미터받기
		int no = Integer.parseInt(request.getParameter("no")); //글번호
		String title   = request.getParameter("title");//글제목
		String content = request.getParameter("content");//글내용
		
		//2.비즈니스로직(<->Service<->DAO<->DB) p670 68
		HttpSession session = request.getSession();
		User authUser=(User)session.getAttribute("AUTHUSER"); //세션에 저장된 로그인유저의id,이름
		DeleteRequest delReq = new DeleteRequest(
				authUser.getemail(),
				no,
				title,
				content
			);
		
		//에러정보  p670 77
		Map<String,Boolean> errors = new HashMap<>();
		request.setAttribute("errors",errors);
		delReq.validate(errors);
		if(!errors.isEmpty()) { //에러가 존재하면
			return FORM_VIEW;   //수정폼으로 이동
		}

		//3.Model P670 75
		request.setAttribute("delREQ", delReq);
		
		//P670 84
		try {
			deleteService.delete(delReq);
			return "/view/admin/notice/notice_deleMessage.jsp";
		}catch(ArticleNotFoundException e) {
			response.sendError(HttpServletResponse.SC_NOT_FOUND);
			return null;
		}catch(PermissionDeniedException e) {
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			return null;
		}
	}

	//p669 38
	private String processForm(HttpServletRequest request, 
			HttpServletResponse response) throws IOException {
		//1.파라미터받기
		int no = Integer.parseInt(request.getParameter("no")); //글번호
		
		//2.비즈니스로직(<->Service<->DAO<->DB)
		/*수정폼이 user에게 보여줄 때에는
		 * 해당 게시글의 글번호,제목,내용이 폼안에 뿌려져있어야 한다 
		 * select * from article         where article_no=?
		 * select * from article_content where article_no=?
		 * (select쿼리결과)*/
		//상세내용조회는 ReadArticleService의 getArticle()구현해놓은 것을 이용하자
		//단 조회수는 증가시키지 않을 것이므로 false주자  P670 1
		ArticleData articleData  = 
			readService.getArticle(no, false);
		HttpSession session = request.getSession();
		User authUser=(User)session.getAttribute("AUTHUSER"); //세션에 저장된 로그인유저의id,이름
		
		//p670 61
		//로그인한 유저의 id가  게시글작성자의 id일치 비교
		//일치하면  true, 불일치하면  false리턴하는 함수호출
		if(!canModify(authUser,articleData)) { //불일치하면
			//403 : Forbidden, 접근이 거부된 문서를 요청한 상태.
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			return null;
		}
		
		//ModifyRequest는 p666
		DeleteRequest delReq = new DeleteRequest(
				authUser.getemail(),
				no,
				articleData.getArticle().getTitle(),
				articleData.getContent().getContent()
			);
		
		//3.Model P670 53
		request.setAttribute("delREQ", delReq);
		
		//4.View
		return FORM_VIEW;
	}

	//p670 61
	//로그인한 유저의 id가  게시글작성자의 id일치 비교
	//일치하면  true, 불일치하면  false리턴하는 함수호출
	private boolean canModify(User authUser, ArticleData articleData) {
		//게시글작성자의 id
		String writerId = articleData.getArticle().getWriter().getId();
		
		//로그인한유저의id.equals(게시글작성자의id)
		return authUser.getemail().equals(writerId);
	}

}








