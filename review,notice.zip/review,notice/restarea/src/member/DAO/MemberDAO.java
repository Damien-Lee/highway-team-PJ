package member.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

import jdbc.JdbcUtil;
import member.MODEL.Member;

//p592
//Mysql의  board데이터베이스의 member테이블에 쿼리
//LoginService, JoinService에서 호출되는 함수를 선언
public class MemberDAO {

	//유저가 입력한 id를 가진 회원이 존재하는 확인
	//회원으로 존재하면 회원정보가 Member객체로 리턴
	//회원으로 존재x  회원정보가 Member객체가 null리턴
	/*SELECT  memberid, name, password, regdate
		FROM 	member
		WHERE	memberid=?;*/
	//p593
	public Member selectById(Connection conn, String email) 
			throws SQLException {
		System.out.println("MemberDAO-selectById(email)호출="+email);
		
		PreparedStatement pstmt = null;
		ResultSet rs  = null;
		Member member = null;
		
		String sql = " SELECT  email, name, password, birth " + 
					 "	FROM 	member " + 
					 "	WHERE	email=?";
		
		try {
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, email);
			rs = pstmt.executeQuery();
			System.out.println("MemberDAO-try문 진입="+sql);
			if( rs.next() ) {  //유저가 입력한 id인 회원이 존재하는 경우
				System.out.println("입력한 id가 존재하는 경우+"+rs);
				//교재p592 25~ p593 29
				/*member = new Member(rs.getString("memberid"),
						rs.getString("name"),
						rs.getString("password"),
						toDate(rs.getTimestamp("regdate"));*/
				
				String memberemail = rs.getString("email");
				String name     = rs.getString("name");
				String password = rs.getString("password");
				System.out.println("혹시 생일 때문일까요???ㅠㅠ");
				String birthday =rs.getString("birth");
				System.out.println("MemberDAO-유저 아이디가 존재할 시="+name);
				member = new Member(memberemail,name,password,birthday);	
			}
			
			return member;
		}finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}
	}//end of selectById()
		
		
	//p593 38
	




	//회원가입 p593-42
	/*INSERT INTO member(memberid,name,password,regdate)
		VALUES(memberid?,name?,password?,regdate?)*/
	public void  insert(Connection conn,Member mem)
		throws SQLException {
		System.out.println("MemberDAO-insert()호출");
		String sql = "INSERT INTO member(email,name,password,birth) " + 
				     " VALUES(?,?,?,?)";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1,mem.getemail());
		pstmt.setString(2,mem.getName());
		pstmt.setString(3,mem.getPassword());
		pstmt.setString(4, mem.getbirthday());
		pstmt.executeUpdate();
	}

	//p620 17
	public void update(Connection conn, Member member)
			throws SQLException {
		System.out.println("MemberDAO-update()호출");
		String sql = "UPDATE  member " + 
				"	  SET	  name=?, password = ? " + 
				"	  WHERE   email = ?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, member.getName());
		pstmt.setString(2, member.getPassword());
		pstmt.setString(3, member.getemail());
		pstmt.executeUpdate();
	}

	
}







