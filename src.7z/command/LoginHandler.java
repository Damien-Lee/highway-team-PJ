package auth.command;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import auth.service.LoginFailException;
import auth.service.LoginService;
import auth.service.User;
import mvc.command.CommandHandler;

public class LoginHandler implements CommandHandler{
	private static final String FORM_VIEW = "WEB-INF/view/login.jsp"; // 폼의 주소
	private LoginService loginService = new LoginService();				//로그인 서비스 클래스를 가져온다.
	@Override
	public String process(HttpServletRequest req, HttpServletResponse res)
			throws Exception { //유니크 뭐시기? 작업 진행함.
		if(req.getMethod().equalsIgnoreCase("GET")) {    ///get과 post형식의 폼을 가져올때 대소문자 구분없이 가져옴.(get,GET,post,POST) 
			return processForm(req,res);  //폼에서 등록한 회원 내용을 리턴 (가져옴)
		}else if(req.getMethod().equalsIgnoreCase("POST")){
			return processSubmit(req,res); //id와 비밀번호를 가져온다고 생각하면 편할듯함.
		}else {
			res.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return null;  //허용되지 않은 메소드?가 오면 null 리턴.
		}
	}
	private String processForm(HttpServletRequest req, HttpServletResponse res) {
		return FORM_VIEW;
	}
	
	private String processSubmit(HttpServletRequest req, HttpServletResponse res) throws Exception{
		String id =trim(req.getParameter("id"));
		String password = trim(req.getParameter("password"));  //파라미터 id와 password를 가져온다. html의 'name'지정값을 가져옴
		Map<String, Boolean> errors = new HashMap<>();
		req.setAttribute("errors", errors);
		
		if(id==null||id.isEmpty()) 
			errors.put("id", Boolean.TRUE);
		if(password==null||password.isEmpty()) 
			errors.put("password", Boolean.TRUE);
		if(!errors.isEmpty()) {
			return FORM_VIEW;
		}

	try{
		User user=loginService.login(id, password);
		req.getSession().setAttribute("authUser",user);
		res.sendRedirect(req.getContextPath()+"/main.jsp");//메인화면
		return null;
	}catch(LoginFailException e) {
		errors.put("idOrPwNotMatch", Boolean.TRUE);
		return FORM_VIEW;
		}
	}
	private String trim(String str) {
		return str==null? null:str.trim();
	}
}
