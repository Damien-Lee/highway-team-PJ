package auth.service;

import java.sql.Connection;
import java.sql.SQLException;

import husik.member;
import husik.memberDAO;
import jdbc.connection.ConnectionProvider;

public class LoginService { //책 예제에서는 MemberDao -> memberDAO로 진행.
	private memberDAO memberDao = new memberDAO();
	
	public User login(String id, String password) { // LOGIN메소드 생성 ID와 PW로 구성되어있다.
		try (Connection conn= ConnectionProvider.getConnection()){ //DB와 연결.
			member member = memberDao.selectById(conn, id); //ID를 가져온다.
			if(member ==null) { //ID가 비어있다면(DB에 없으면)
				throw new LoginFailException();  //익센셥 발생
			}
			if(!member.matchPassword(password)) { //비밀번호를 매칭해본다.
				throw new LoginFailException(); //비밀번호 불일치시 오류발생.
			}
			return new User(member.getId(), member.getName());//책 예제에서는 이름이지만, 여기에서는 닉네임이다.
			
		}catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
